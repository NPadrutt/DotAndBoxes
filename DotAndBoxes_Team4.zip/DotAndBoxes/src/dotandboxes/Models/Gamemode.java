package dotandboxes.Models;

/**
 *
 * @author Nino
 */
public enum Gamemode{
        Local,
        Network
 }
